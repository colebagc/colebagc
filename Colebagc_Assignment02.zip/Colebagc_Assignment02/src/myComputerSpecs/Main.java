/*
 * Gavin Colebank
 * colebagc@mail.uc.edu
 * Computer Programming II
 * Assignment 02
 * This project models the specifications of my newly built PC
 * Due 1/28/2021
 */
package myComputerSpecs;

public class Main {

	public static void main(String[] args) {
		int RamStickSize;
		MyComputerSpecs myBuild;
		// Instantiate an object and store the reference in out variable.
		// String cpuModel, String gpuModel, int gbOfRam, int numberOfDimmSlotsUsed
		myBuild = new MyComputerSpecs("AMD Ryzen 7 1700X", "AMD Radeon RX 580 OC", 32, 2);
		RamStickSize = myBuild.determineGbPerDimmSlot();
		System.out.println(RamStickSize);

	}

}
