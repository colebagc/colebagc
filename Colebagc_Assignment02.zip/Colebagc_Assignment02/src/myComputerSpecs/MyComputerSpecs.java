/*
 * Gavin Colebank
 * colebagc@mail.uc.edu
 * Computer Programming II
 * Assignment 02
 * This project models the specifications of my newly built PC
 * Due 1/28/2021
 */
package myComputerSpecs;

public class MyComputerSpecs {
	// Property List
	private String cpuModel;
	private String gpuModel;
	private int gbOfRam;
	private int numberOfDimmSlotsUsed;
	
	public MyComputerSpecs(String cpuModel, String gpuModel, int gbOfRam, int numberOfDimmSlotsUsed ) {
		 // Copy from the method parameters into the private properties of the class.
		 this.cpuModel = cpuModel;
		 this.gpuModel = gpuModel;
		 this.gbOfRam = gbOfRam;
		 this.numberOfDimmSlotsUsed = numberOfDimmSlotsUsed;
	 }
	
	public int determineGbPerDimmSlot() {
		gbOfRam = 32;
		numberOfDimmSlotsUsed = 2;
		int GbperDimmSlot = gbOfRam/numberOfDimmSlotsUsed;
		return GbperDimmSlot;
	}

	/**
	 * Get the CPU model
	 * @return CPU model
	 */
	
	public String getCpuModel() {
		return cpuModel;
	}
	
	/**
	 * Define CPU model
	 * @param cpuModel The CPU model. Can't be blank or will throw an exception. 
	 * @throws Exception
	 */
	
	public void setCpuModel(String cpuModel) throws Exception {
		if (cpuModel.trim().length() == 0 ) {
			throw new Exception ("cpuModel can't be blank");
		} else {
			this.cpuModel = cpuModel;
		}
	}
	
	/**
	 * Get the number GB of RAM
	 * @return Amount of RAM
	 */

	public int getGbOfRam() {
		return gbOfRam;
	}
	
	/**
	 * Define GB of RAM
	 * @param gbOfRam Amount of RAM in GB. Can't be blank or will throw an exception
	 */

	public void setGbOfRam(int gbOfRam) throws Exception {
		if (gbOfRam == 0 ) {
			throw new Exception ("gbOfRam can't be blank");
		} else {
			this.gbOfRam = gbOfRam;
		}
	}
	
	/**
	 * Get the GPU Model
	 * @return The GPU Model
	 */

	public String getGpuModel() {
		return gpuModel;
	}
	
	/**
	 * Define the GPU Model
	 * @param gpuModel The GPU Model. Can't be blank or will thrown an exception
	 */

	public void setGpuModel(String gpuModel) throws Exception {
		if (gpuModel.trim().length() == 0) {
			throw new Exception ("gpuModel can't be blank");
		} else {
			this.gpuModel = gpuModel;
		}
			
	}
	
	/**
	 * Get the number of Dimm slots used
	 * @return the number of dimm slots used for our memory.
	 */

	public int getNumberOfDimmSlotsUsed() {
		return numberOfDimmSlotsUsed;
	}
	
	/**
	 * Defines the number of dimm slots used
	 * @param numberOfDimmSlotsUsed Dimm slots used. Can't be blank or will throw an exception.
	 */

	public void setNumberOfDimmSlotsUsed(int numberOfDimmSlotsUsed) throws Exception {
		if (numberOfDimmSlotsUsed == 0) {
			throw new Exception ("numberOfDimmSlotsUsed cannot be blank");
		} else {
			this.numberOfDimmSlotsUsed = numberOfDimmSlotsUsed;
		}
	}


}
