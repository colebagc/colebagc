/*
 * Gavin Colebank
 * colebagc@mail.uc.edu
 * Computer Programming II
 * Assignment 03
 * This project models a character in Super Smash Bros
 * Due 02/04/2021
 */
package colebagc_Assignement03;

public class Main {

	public static void main(String[] args) {
		// Declare and Instantiate 5 objects 
		SuperSmashBrothersMeleeCharacter Mario;
		SuperSmashBrothersMeleeCharacter Luigi;
		SuperSmashBrothersMeleeCharacter DonkeyKong;
		SuperSmashBrothersMeleeCharacter Link;
		SuperSmashBrothersMeleeCharacter Samus;
		Mario = new SuperSmashBrothersMeleeCharacter("Mario", 98, 1.70, 0.86, 1.44, 1.50);
		Luigi = new SuperSmashBrothersMeleeCharacter("Luigi", 0, 1.60, 0.68, 0.00, 1.34);
		DonkeyKong = new SuperSmashBrothersMeleeCharacter("Donkeyk", 0, 2.40, 1.00, 0.00, 1.60);
		Link = new SuperSmashBrothersMeleeCharacter("Link", 0, 2.13, 1.00, 0.00, 1.30);
		Samus = new SuperSmashBrothersMeleeCharacter("Samus", 0, 1.40, 0.89, 0.00, 1.40);
		System.out.println("Character Name" + "  " + "Weight" +"  " +  "Falling Speed" +"  " +  "Air Speed" +"  " +  "Size" +"  " +  "Dash Speed");
		System.out.println(Mario.toString());
		System.out.println(Luigi.toString());
		System.out.println(DonkeyKong.toString());
		System.out.println(Link.toString());
		System.out.println(Samus.toString());
		

	}

}
