/*
 * Gavin Colebank
 * colebagc@mail.uc.edu
 * Computer Programming II
 * Assignment 03
 * This project models a character in Super Smash Bros
 * Due 02/04/2021
 */
package colebagc_Assignement03;

public class SuperSmashBrothersMeleeCharacter {
	// Property List
	private String characterName;
	private int weight;
	private double fallingSpeed;
	private double airSpeed;
	private double size;
	private double dashSpeed;
	
	// Constructor that accepts all of the properties
	public SuperSmashBrothersMeleeCharacter(String characterName, int weight, double fallingSpeed, double airSpeed, double size, double dashSpeed) {
		setCharacterName(characterName);
		setWeight(weight);
		setFallingSpeed(fallingSpeed);
		setAirSpeed(airSpeed);
		setSize(size);
		setDashSpeed(dashSpeed);
	}
	
	// Default Constructor. Defaults all properties to blank/0
	public SuperSmashBrothersMeleeCharacter() {
		characterName = "";
		weight = 0;
		fallingSpeed = 0;
		airSpeed = 0;
		size = 0;
		dashSpeed = 0;
	}
	
	public String toString() {
		 return getCharacterName() + "            " + getWeight() + "        " + getAirSpeed() + "          " + getFallingSpeed() + "      " + getSize() + "     " + getDashSpeed();
	}
	
	/**
	 * Get the character name
	 * @return character name
	 */
	
	public String getCharacterName() {
		return characterName;
	}
	
	/**
	 * Define character name
	 * @param characterName
	 */
	
	public void setCharacterName(String characterName) {
		this.characterName = characterName;
	}
	
	/**
	 * get the weight of the character
	 * @return weight of the character
	 */

	public int getWeight() {
		return weight;
	}
	
	/**
	 * Define characters weight
	 * @param weight
	 */

	public void setWeight(int weight) {
		this.weight = weight;
	}
	
	/**
	 * Get character falling speed
	 * @return character falling speed
	 */

	public double getFallingSpeed() {
		return fallingSpeed;
	}
	
	/**
	 * Define character falling speed
	 * @param fallingSpeed
	 */

	public void setFallingSpeed(double fallingSpeed) {
		this.fallingSpeed = fallingSpeed;
	}
	
	/**
	 * Get character air speed
	 * @return character air speed
	 */
	
	public double getAirSpeed() {
		return airSpeed;
	}
	
	/**
	 * Define character air speed
	 * @param airSpeed
	 */

	public void setAirSpeed(double airSpeed) {
		this.airSpeed = airSpeed;
	}
	
	/**
	 * Get character size
	 * @return character size
	 */

	public double getSize() {
		return size;
	}
	
	/**
	 * Define character size
	 * @param size
	 */

	public void setSize(double size) {
		this.size = size;
	}
	
	/**
	 * Get character DashSpeed
	 * @return character DashSpeed
	 */

	public double getDashSpeed() {
		return dashSpeed;
	}
	
	/**
	 * Set character DashSpeed
	 * @param dashSpeed
	 */

	public void setDashSpeed(double dashSpeed) {
		this.dashSpeed = dashSpeed;
	}

}
