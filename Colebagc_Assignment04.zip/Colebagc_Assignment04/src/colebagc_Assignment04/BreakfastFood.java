/*
 * Gavin Colebank
 * colebagc@mail.uc.edu
 * Computer Programming II
 * Assignment 04
 * Due 2/11/2021
 * This program demonstrates inheritance
 */
package colebagc_Assignment04;

public class BreakfastFood {
	// Add our properties
	private int totalCaloriesPerServing;
	private boolean glutenFree; //True or False
	
	/**
	 * Constructor that accepts our properties
	 * @param totalCaloriesPerServing
	 * @param glutenFree
	 * @param isfrosted 
	 * @param flavor 
	 */
	public BreakfastFood (int totalCaloriesPerServing, boolean glutenFree) {
		setTotalCaloriesPerServing(totalCaloriesPerServing);
		setGlutenFree(glutenFree);
	}

	public String toString() {
		return getTotalCaloriesPerServing() + " " + getIsGlutenFree();
	}
	
	/**
	 * Get our boolean that tells us if the food is gluten free or not.
	 * @return yes or no
	 */

	public boolean getIsGlutenFree() {
		return glutenFree;
	}
	
	/**
	 * Define glutenFree
	 * @param glutenFree
	 */

	public void setGlutenFree(boolean glutenFree) {
		this.glutenFree = glutenFree;
	}
	
	/**
	 * Get our integer for total calories per serving
	 * @return total calories per serving
	 */

	public int getTotalCaloriesPerServing() {
		return totalCaloriesPerServing;
	}
	
	/**
	 * Define total calories per serving
	 * @param totalCaloriesPerServing
	 */

	public void setTotalCaloriesPerServing(int totalCaloriesPerServing) {
		this.totalCaloriesPerServing = totalCaloriesPerServing;
	}
	

}
