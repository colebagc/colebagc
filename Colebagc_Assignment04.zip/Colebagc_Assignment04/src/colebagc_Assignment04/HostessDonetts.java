/*
 * Gavin Colebank
 * colebagc@mail.uc.edu
 * Computer Programming II
 * Assignment 04
 * Due 2/11/2021
 * This program demonstrates inheritance
 */
package colebagc_Assignment04;

public class HostessDonetts extends PopTart{
	
	// Add our properties
	private boolean isMessy;
	private String packageSize;
	
	/**
	 *  Constructor that accepts our properties
	 * @param totalCaloriesPerServing
	 * @param glutenFree
	 * @param flavor
	 * @param isfrosted
	 * @param donutFlavor
	 * @param packageSize
	 */
	
	public HostessDonetts(int totalCaloriesPerServing, boolean glutenFree, String flavor, boolean isFrosted, boolean isMessy, String packageSize) {
		super(totalCaloriesPerServing, glutenFree, flavor, isFrosted);
		setIsMessy(isMessy);
		setPackageSize(packageSize);
	}
	
	public String toString() {
		return super.toString() + "  " + getIsMessy() + "  " + getPackageSize();
	}
	
	
	/**
	 * Get the donut package size
	 * @return donut package size
	 */
	
	public String getPackageSize() {
		return packageSize;
	}
	
	/**
	 * Define the donut package size
	 * @param size
	 */
	
	public void setPackageSize(String packageSize) {
		this.packageSize = packageSize;
	}
	
	/**
	 * Get if the donette is messy
	 * @return if the donette is messy
	 */

	public boolean getIsMessy() {
		return isMessy;
	}
	
	/**
	 * Define if the donette is messy
	 * @param isMessy
	 */

	public void setIsMessy(boolean isMessy) {
		this.isMessy = isMessy;
	}

	
	
}