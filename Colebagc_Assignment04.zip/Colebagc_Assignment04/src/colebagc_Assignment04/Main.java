/*
 * Gavin Colebank
 * colebagc@mail.uc.edu
 * Computer Programming II
 * Assignment 04
 * Due 2/11/2021
 * This program demonstrates inheritance
 */
package colebagc_Assignment04;

public class Main {

	public static void main(String[] args) {
		// Declare and Instantiate our objects
		BreakfastFood eggs;
		PopTart chocolateChip;
		HostessDonetts powdered;
		
		eggs = new BreakfastFood (350, false);
		chocolateChip = new PopTart (90, false, "Chocolate Chip", true);
		powdered = new HostessDonetts (130, false, "Powdered", false, true, "Small");
		
		// Print out to console
		System.out.println("Total Calories, Gluten Free or not, Flavor, is it frosted, is it messy, package size");
		System.out.println("Eggs: " + eggs.toString());
		System.out.println("Chocolate Chip PopTart: " + chocolateChip.toString());
		System.out.println("Hostess Donetts: " + powdered.toString());
		

	}

}
