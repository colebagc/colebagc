/*
 * Gavin Colebank
 * colebagc@mail.uc.edu
 * Computer Programming II
 * Assignment 04
 * Due 2/11/2021
 * This program demonstrates inheritance
 */
package colebagc_Assignment04;

public class PopTart extends BreakfastFood {

	// Add our properties
	private String flavor;
	private boolean isFrosted;
	
	/**
	 *  Constructor that accepts our properties
	 * @param totalCaloriesPerServing
	 * @param glutenFree
	 * @param flavor
	 * @param isfrosted
	 */
	
	public PopTart(int totalCaloriesPerServing, boolean glutenFree, String flavor, boolean isFrosted) {
		super(totalCaloriesPerServing, glutenFree);
		setFlavor(flavor);
		setFrosted(isFrosted);
	}
	
	public String toString() {
		return super.toString() + "  " + getFlavor() + "  " + getIsFrosted();
	}
		
	/**
	 * Get the flavor of the poptart
	 * @return flavor of the poptart
	 */
	
	public String getFlavor() {
		return flavor;
	}
	
	/**
	 * Define the poptart flavor
	 * @param flavor
	 */
	
	public void setFlavor(String flavor) {
		this.flavor = flavor;
	}
	
	/**
	 * Get if the poptart is frosted or not
	 * @return if the poptart is frosted or not
	 */
	
	public boolean getIsFrosted() {
		return isFrosted;
	}
	
	/**
	 * Define if the poptart is frosted or not
	 * @param isFrosted
	 */
	
	public void setFrosted(boolean isFrosted) {
		this.isFrosted = isFrosted;
	}

}
