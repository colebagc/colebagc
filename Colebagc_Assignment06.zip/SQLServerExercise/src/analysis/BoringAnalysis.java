/*
 * 
 * Gavin Colebank
 * colebagc@mail.uc.edu
 * Assignment 06
 * 
 * 
 * Bill Nicholson
 * 
 * nicholdw@ucmail.uc.edu
 */
package analysis;

import java.util.ArrayList;



/***
 * Analyze a list of words in a boring and uninteresting manner
 * @author nicomp
 *
 */
public class BoringAnalysis implements Analyze {

	/**
	 * Loop through the ArrayList to see which words in the word list start with the letter 'A'
	 */
	
	@Override
	public void analyzeAndPrint(ArrayList<String> wordList) {
		
		int count = 0;
		for (String tmp : wordList) {
			if (tmp.startsWith("A")) {
				count++;
			}
		}
		
		System.out.println(count + " is the number of words in the list that strart with the letter A");
		
	}

}
