/*
 * 
 * Gavin Colebank
 * colebagc@mail.uc.edu
 * Assignment 06
 * 
 * 
 * Bill Nicholson
 * 
 * nicholdw@ucmail.uc.edu
 */

package analysis;

import java.util.ArrayList;

/***
 * Analyze a list of words in a fascinating and engrossing manner
 * @author nicomp
 *
 */

public class InterestingAnalysis implements Analyze {
	
	/**
	 * Loop through the ArrayList to see which words in the word list start with the letter 'K' and also contain the letter 'a'
	 */

	@Override
	public void analyzeAndPrint(ArrayList<String> wordList) {

		int count = 0;
		for (String tmp : wordList) {
			if (tmp.startsWith("K")) {
				if (tmp.contains("a")) {
					count++;
				}
			}
		}
		
		System.out.println(count + " is the number of words in the list that strart with the letter K and contain the letter a");
		
	}

}
