/*
 * checkSpelling method implemented by Gavin Colebank
 * colebagc@mail.uc.edu
 * Assignment 07
 * Due March 25th 2021
 */

package wordProcessor;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Hashtable;

/***
 * Model some utilities that could be used to process words
 * @author nicomp
 *
 */
public class WordProcessor {
	/**
	 * Look for a word in the dictionary and check possible misspellings
	 * @param target The word to look for
	 * @param words The dictionary
	 * @return The matching word in the dictionary or "" if no match
	 */
	public String checkSpelling(String target, Hashtable<String, String> words) {
		String foundWord = "";
		// Checks if the target is in the hashtable, if not
		if (words.get(target) == null) {
			// If not in the hashtable, check for a spelling error. 
			// Convert to character array in order to retrieve characters
			char[] chars = target.toCharArray();
			// Loop through target - 1
			for (int i = 0; i < target.length() -1; i++) {
				// Transpose the target
				char temp = chars[i];
				chars[i] = chars[i + 1];
				chars[i + 1] = temp;
				// Check if transposed target is in the hashtable; If it is, return it
				if (words.get(chars.toString()) != null) {
					foundWord = chars.toString();
				}
			}
			// If original target is in the hashtable, return it
		} else {
			foundWord = target;
			return foundWord;
		}
		// Here so we don't get a build error :/
		return foundWord;
	}

	/***
	 * Read words from a text file
	 * @param fileName The file to open and read
	 * @return The Hashtable containing all the words in the file. 
	 */
	public Hashtable<String, String> readWords(String fileName) {
		Hashtable<String, String> words = new Hashtable<String, String>();
		BufferedReader br = null;
		try {
		  br = new BufferedReader(new FileReader(fileName)); 	  
		  String word; 
		  while ((word = br.readLine()) != null) {
		    words.put(word, word);		// Use the word as the key and the value 
		  } 
		} catch (Exception ex) {
			System.out.println("Error reading " + fileName + ": " + ex.getLocalizedMessage());
		}
		try {br.close();} catch(Exception ex) {}
		return words;
	}
}
